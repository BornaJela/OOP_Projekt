#include "Pipe.h"
#include"Globals.h"
Pipe::Pipe(int y_pos)
{
	sprite_down.setTexture(texture_down);
	sprite_up.setTexture(texture_up);

	sprite_down.setScale(SCALE_FACTOR, SCALE_FACTOR);
	sprite_up.setScale(SCALE_FACTOR, SCALE_FACTOR);
	//gornja cijev na y_pos, donja je gornja -razmak izmedju njih 2 - visina gornje (samo se gornja generira, donja
	// se izracuna pomocu ovoga)
	sprite_up.setPosition(WIN_WIDTH, y_pos);
	sprite_down.setPosition(WIN_WIDTH, y_pos - pipe_distance - sprite_up.getGlobalBounds().height);
}
//brzina pipeova, idu ulijevo i povecava se
void Pipe::update(sf::Time& dt)
{
	sprite_up.move(-move_speed * dt.asSeconds(), 0.f);
	sprite_down.move(-move_speed * dt.asSeconds(), 0.f);

}

void Pipe::loadTextures()
{
	texture_down.loadFromFile("assets/pipedown.png");
	texture_up.loadFromFile("assets/pipe.png");
}
//desna koordinata cijevi, da znamo kada povecati score
float Pipe::getRightBound()
{
	return sprite_down.getGlobalBounds().left + sprite_down.getGlobalBounds().width;
}
//staticki clanovi koje koristimo samo u cpp, ucitava se samo jednom pri pozivu (stedi memoriju)
sf::Texture Pipe::texture_down, Pipe::texture_up;
int Pipe::pipe_distance = 170, Pipe::move_speed = 400;